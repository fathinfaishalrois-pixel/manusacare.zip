<?php $__env->startSection('title', $admin ? 'Admin Login' : 'Login'); ?>
<?php $__env->startSection('content'); ?>
<section class="auth-wrap">
    <div class="auth-intro" data-reveal>
        <span class="eyebrow"><span class="eyebrow-index">01</span><?php echo e($admin ? 'Restricted access' : 'Welcome back'); ?></span>
        <h1><?php echo e($admin ? 'Admin control' : 'Satu langkah untuk'); ?> <em><?php echo e($admin ? 'center.' : 'sekolah lebih baik.'); ?></em></h1>
        <p><?php echo e($admin ? 'Halaman khusus pengelola sistem MANUSACARE. Gunakan akun administrator yang terdaftar.' : 'Masuk menggunakan NIS/NIP atau email yang terhubung dengan akunmu.'); ?></p>
        <div class="register-points">
            <div>
                <span>01</span>
                <p><b>Akses terverifikasi</b><small>Setiap peran hanya membuka area yang menjadi tanggung jawabnya.</small></p>
            </div>
            <div>
                <span>02</span>
                <p><b>Riwayat tersimpan</b><small>Status dan catatan penanganan tetap dapat dipantau setelah masuk.</small></p>
            </div>
        </div>
    </div>

    <form class="glass-form auth-card" method="POST" action="<?php echo e($admin ? route('admin.login.store') : route('login.store')); ?>" data-reveal>
        <?php echo csrf_field(); ?>
        <div class="form-heading">
            <span class="eyebrow"><?php echo e($admin ? 'Administrator' : 'Akun pelapor'); ?></span>
            <h2><?php echo e($admin ? 'Administrator login' : 'Masuk ke akun'); ?></h2>
            <p><?php echo e($admin ? 'Akses terbatas untuk pengelola sistem.' : 'Gunakan data akun yang sudah terdaftar.'); ?></p>
        </div>

        <div class="field <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <label for="login"><?php echo e($admin ? 'Email atau ID Admin' : 'NIS / NIP / NIK / Email'); ?> <span>*</span></label>
            <input id="login" name="login" value="<?php echo e(old('login')); ?>" required autofocus autocomplete="username" maxlength="150" <?php if($errors->has('login')): ?> aria-describedby="login-error" aria-invalid="true" <?php endif; ?>>
            <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error" id="login-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="field <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <label for="password">Kata sandi <span>*</span></label>
            <div class="password-field">
                <input id="password" type="password" name="password" required autocomplete="current-password" <?php if($errors->has('password')): ?> aria-describedby="password-error" aria-invalid="true" <?php endif; ?>>
                <button class="password-toggle" type="button" data-password-toggle="password" aria-controls="password" aria-pressed="false" aria-label="Tampilkan kata sandi">
                    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'eye']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'eye']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                </button>
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error" id="password-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <label class="remember"><input type="checkbox" name="remember" value="1" <?php if(old('remember')): echo 'checked'; endif; ?>> Ingat saya</label>

        <button class="button button-primary button-large w-full" type="submit">Masuk <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></button>

        <?php if (! ($admin)): ?>
            <p class="form-foot">Belum punya akun? <a href="<?php echo e(route('register')); ?>">Daftar sekarang</a></p>
            <p class="form-foot admin-note">Akun petugas dan admin dibuat oleh administrator sekolah.</p>
        <?php else: ?>
            <p class="form-foot admin-note">Akses khusus administrator sekolah. Hubungi pengelola sistem jika akun tidak dapat digunakan.</p>
        <?php endif; ?>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\manusacare\resources\views/auth/login.blade.php ENDPATH**/ ?>