<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $states = [
        'dikirim' => ['label' => 'Dikirim', 'tone' => 'submitted'],
        'diproses' => ['label' => 'Diproses', 'tone' => 'progress'],
        'selesai' => ['label' => 'Selesai', 'tone' => 'completed'],
        'ditolak' => ['label' => 'Ditolak', 'tone' => 'rejected'],
    ];
    $state = $states[$status] ?? ['label' => ucfirst((string) $status), 'tone' => 'neutral'];
?>

<span <?php echo e($attributes->merge(['class' => 'status-pill status-'.$state['tone']])); ?>>
    <span class="status-dot" aria-hidden="true"></span><?php echo e($state['label']); ?>

</span>
<?php /**PATH C:\laragon\www\manusacare\resources\views/components/status-pill.blade.php ENDPATH**/ ?>