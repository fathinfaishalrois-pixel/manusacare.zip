MANUSACARE PATCH - ANIMATION LIBRARIES
======================================

Patch: manusacare-patch-v4-animation-libraries.zip
Basis: manusacare(3).zip (uploaded 23 November 2026)
Scope: Frontend animation integration only.

FILES TO REPLACE / ADD
----------------------
ADD    public/js/animation-engine.js
EDIT   public/css/app.css
EDIT   resources/views/layouts/app.blade.php
EDIT   package.json

WHAT CHANGED
------------
- GSAP + ScrollTrigger: opt-in scroll reveal via [data-gsap-reveal].
- Motion: opt-in micro-interactions via [data-motion-hover] and
  [data-motion-inview].
- Lenis: smooth wheel scrolling on fine-pointer desktop devices.
- Existing public/js/app.js and existing application interactions are untouched.
- Respects prefers-reduced-motion. On touch/coarse-pointer devices, Lenis and
  hover micro-interactions are skipped to preserve native touch behavior.
- Animation modules are loaded lazily from pinned jsDelivr ESM URLs. If the
  CDN is unavailable, the existing application continues with native CSS and
  JavaScript behavior.

INSTALLATION
------------
1. Extract this ZIP into the MANUSACARE project root.
2. Allow the listed files to be added/replaced.
3. No database migration is required.
4. No Vite build is required for this patch.
5. Ensure the browser can reach cdn.jsdelivr.net for the animation libraries.
6. Hard-refresh the browser after deployment.

OPTIONAL LOCAL DEPENDENCIES
---------------------------
package.json now declares gsap, motion, and lenis. If you later move this
animation runtime into the Vite build pipeline, run `npm install` first.
This patch currently loads the pinned ESM builds directly so it works with
the project's existing public asset layout.

NOTES
-----
- No files were deleted or moved.
- No vendor, node_modules, .env, database, or storage files are included.
- This patch does not change report workflows, authentication, permissions,
  routes, or database structure.
